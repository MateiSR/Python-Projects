elephant - https://github.com/mateisr/elephant/
1. install BalsamiqSans & Roboto fonts
2. run elephant.py